﻿#include <bits/stdc++.h>
using namespace std;
const int N = 1e3 + 10;
int dp[N][N];
char s1[N], s2[N];
int main() {
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    scanf("%s %s", s1, s2);
    int len1 = strlen(s1), len2 = strlen(s2);

    for (int i = 1; i <= len1; i++)
        dp[i][0] = 0;

    for (int i = 1; i <= len2; i++)
        dp[0][i] = 0;

    for (int i = 1; i <= len1; i++) {
        for (int j = 1; j <= len2; j++) {
            if (s1[i - 1] == s2[j - 1])
                dp[i][j] = dp[i - 1][j - 1] + 1;
            else
                dp[i][j] = max(dp[i][j - 1], dp[i - 1][j]);
        }
    }

    printf("%d\n", dp[len1][len2]);

    stack<char> s;
    int i = len1, j = len2;
    while (dp[i][j]) {
        if (dp[i][j] == dp[i - 1][j])  // 来自于左方向
            --i;
        else if (dp[i][j] == dp[i][j - 1])  // 来自于上方向
            --j;
        else if (dp[i][j] > dp[i - 1][j - 1]) {  // 来自于左上方向
            --i;
            --j;
            s.push(s1[i]);
        }
    }
    while (!s.empty()) {
        printf("%d", s.top());
        s.pop();
    }
    puts("");
    for (int i = 1; i <= len1; i++)
        for (int j = 1; j <= len2; j++)
            printf("%d%c", dp[i][j], " \n"[j == len2]);
}
